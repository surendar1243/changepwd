package com.sl.util;

public class Setup {
	  public static final String DB_URL = "jdbc:mysql://localhost:3306/demos";
	  public static final String DB_USERNAME = "root";
	  public static final String DB_PASSWORD = "your root user password";
	  public static final String MAIL_USERNAME = "mail id here"; // like example@outlook.com
	  public static final String MAIL_PASSWORD = "password here";  // your mail password here
	  public static final String MAIL_SMTP_HOST = "smtp password here"; // smtp.live.com
	  public static final String MAIL_REGISTRATION_SITE_LINK = "http://localhost:8080/demos/VerifyRegisteredEmailHash";
}
