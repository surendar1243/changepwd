package com.sl.util;

public class GlobalConstants {

	public static final String MESSAGE = "message";
	public static final String SALT = "$2a$10$DOWSDz/CyKaJ40hslrk5fe";
	public static final String USER = "user";
	public static final String ACTIVE = "active";
	public static final String NEW = "new";
	public static final String IN_RESET_PASSWORD = "inResetPassword";
	public static final String IS_RESET_PASSWORD_VERIFIED = "isResetPasswordVerified";
	public static final String RESET_PASSWORD = "resetPassword";
	public static final String ACTIVATION = "activation";
	public static final String YES = "yes";
	public static final String USER_NAME = "userName";
   
}
